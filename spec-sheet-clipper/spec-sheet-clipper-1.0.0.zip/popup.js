const field = id => document.getElementById(id);
const status = message => { field('status').textContent = message; };
async function init() {
  try {
    const [tab] = await chrome.tabs.query({active:true,currentWindow:true});
    if (!tab?.id || !/^https?:\/\//i.test(tab.url || '')) {
      status('Open a product webpage to clip it, or enter the details here.'); return;
    }
    const [{result}] = await chrome.scripting.executeScript({target:{tabId:tab.id},func:()=>({
      name:(document.querySelector('meta[property="og:title"]')?.content || document.title || '').slice(0,300),
      url:location.href.slice(0,2000),
      notes:(window.getSelection()?.toString() || '').slice(0,5000)
    })});
    field('name').value=result.name; field('url').value=result.url; field('notes').value=result.notes;
  } catch { status('This page blocks clipping. You can enter the product details manually.'); }
}
field('clip').addEventListener('submit', async event=>{
  event.preventDefault();
  const save=event.submitter; save.disabled=true;
  try {
    const url=new URL(field('url').value);
    if (!['http:','https:'].includes(url.protocol)) throw new Error('Use an http or https product link.');
    const name=field('name').value.trim(); if(!name) throw new Error('Enter a product name.');
    const item={id:crypto.randomUUID(),name,url:url.href,room:field('room').value.trim(),model:field('model').value.trim(),finish:field('finish').value.trim(),notes:field('notes').value.trim(),savedAt:new Date().toISOString()};
    const {items=[]}=await chrome.storage.local.get('items');
    await chrome.storage.local.set({items:[...items,item]});
    status('Selection saved. Open your spec sheet to review or export it.');
  } catch(error) {status(error.message || 'Could not save. Export your existing selections and try again.');}
  finally {save.disabled=false;}
});
field('open').addEventListener('click',()=>chrome.tabs.create({url:chrome.runtime.getURL('sheet.html')}));
init();
