let items=[], removed=null;
const el=id=>document.getElementById(id);
function node(tag,text){const n=document.createElement(tag);if(text!==undefined)n.textContent=text;return n;}
function safeURL(raw){try{const u=new URL(raw);return ['http:','https:'].includes(u.protocol)?u.href:'';}catch{return '';}}
function csvCell(value){let text=String(value??'');if(/^[\s]*[=+@-]/.test(text)||/^[\t\r]/.test(text))text="'"+text;return '"'+text.replaceAll('"','""')+'"';}
async function removeItem(id){
  const fresh=await chrome.storage.local.get('items'); const current=fresh.items||[];
  removed=current.find(x=>x.id===id);
  await chrome.storage.local.set({items:current.filter(x=>x.id!==id)});
  el('undo').hidden=!removed; el('status').textContent='Selection removed. Undo is available until this page closes.';
}
function render(){
  el('items').replaceChildren();
  if(!items.length){const p=node('p','No selections yet. Open a product page, click Spec Sheet Clipper, and save a selection.');p.className='empty';el('items').append(p);}
  for(const item of items){
    const card=node('article');card.append(node('h2',item.name));
    const dl=node('dl');
    for(const [label,key] of [['Room','room'],['Model / SKU','model'],['Finish','finish'],['Notes','notes']]){dl.append(node('dt',label),node('dd',item[key]||'Not specified'));}
    const url=safeURL(item.url);if(url){const a=node('a',url);a.href=url;a.target='_blank';a.rel='noopener noreferrer';const dd=node('dd');dd.append(a);dl.append(node('dt','Source'),dd);}
    card.append(dl);const actions=node('div');actions.className='actions';const remove=node('button','Remove selection');remove.className='secondary';remove.addEventListener('click',()=>removeItem(item.id).catch(()=>{el('status').textContent='Could not remove this selection.';}));actions.append(remove);card.append(actions);el('items').append(card);
  }
}
el('project').addEventListener('input',async()=>{try{await chrome.storage.local.set({project:el('project').value.trim()});}catch{el('status').textContent='Could not save the project name.';}});
el('print').addEventListener('click',()=>window.print());
el('csv').addEventListener('click',()=>{
  const rows=[['Project','Room','Product','Model / SKU','Finish','Specification notes','Product URL','Saved at'],...items.map(x=>[el('project').value,x.room,x.name,x.model,x.finish,x.notes,x.url,x.savedAt])];
  const blob=new Blob(['\uFEFF'+rows.map(row=>row.map(csvCell).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'});
  const url=URL.createObjectURL(blob);const a=node('a');a.href=url;a.download='nss-remodel-spec-sheet.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
});
el('undo').addEventListener('click',async()=>{if(!removed)return;try{const fresh=await chrome.storage.local.get('items');await chrome.storage.local.set({items:[...(fresh.items||[]),removed]});removed=null;el('undo').hidden=true;el('status').textContent='Selection restored.';}catch{el('status').textContent='Could not restore this selection.';}});
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.items){items=changes.items.newValue||[];render();}if(area==='local'&&changes.project&&document.activeElement!==el('project'))el('project').value=changes.project.newValue||'';});
chrome.storage.local.get(['items','project']).then(data=>{items=data.items||[];el('project').value=data.project||'';render();}).catch(()=>{el('status').textContent='Could not load selections. Reopen the extension and try again.';});
